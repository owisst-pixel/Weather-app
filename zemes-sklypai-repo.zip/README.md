# Žemės sklypų žemėlapis – automatinis surinkimas
1. Įkelkite šį aplanką į GitHub repo, įjunkite **Pages** (Settings → Pages → main / root) ir **Actions** (Settings → Actions → Workflow permissions: Read and write).
2. `scraper/collect.py` → `SOURCES`: įjunkite (`"enabled": True`) ir suderinkite CSS selektorius su tikru puslapiu (naršyklėje: dešinys klik → Inspect). Pakeiskite `UA` URL.
3. Rankiniai sklypai: pridėkite eilučių į `manual/rankiniai.csv` (reikia lat, lng).
4. Paleiskite: Actions → „Sklypų duomenų surinkimas“ → Run workflow. Vėliau veiks kasdien.
5. `index.html` automatiškai įkelia `data/listings.json`.
Lokaliai: `pip install -r scraper/requirements.txt && python scraper/collect.py`
