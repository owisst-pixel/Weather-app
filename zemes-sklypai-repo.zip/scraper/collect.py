#!/usr/bin/env python3
"""Sklypų duomenų surinkėjas -> data/listings.json
Šaltiniai: (1) SOURCES (HTML puslapiai pagal CSS selektorius), (2) manual/*.csv.
SVARBU: SOURCES selektorius reikia suderinti su tikra svetaine (žr. README.md).
Gerbiamas robots.txt; aruodas.lt / skelbiu.lt sąmoningai nėra (jų taisyklės draudžia automatinį rinkimą).
"""
import csv, glob, hashlib, json, re, time, urllib.robotparser
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parent.parent
OUT, GEO = ROOT / "data/listings.json", ROOT / "data/geocache.json"
UA = "ZemesSklypaiBot/1.0 (+https://github.com/YOUR_USER/YOUR_REPO)"
S = requests.Session(); S.headers["User-Agent"] = UA

SOURCES = [
 # PAVYZDYS – suderinkite su tikru evarzytynes.lt HTML (naršyklėje: Inspect Element)
 {"name": "evarzytynes", "enabled": False, "url": "https://www.evarzytynes.lt/",
  "type": "state", "seller": "NŽT / evarzytynes.lt", "pages": 1,
  "item": ".auction-item",
  "fields": {"title": ".title", "price": ".price", "area": ".area", "address": ".address",
             "link": "a@href", "auction": ".end-date", "cad": ".cadastral"}},
]

def allowed(url):
    p = urlparse(url); rp = urllib.robotparser.RobotFileParser(f"{p.scheme}://{p.netloc}/robots.txt")
    try: rp.read(); return rp.can_fetch(UA, url)
    except Exception: return False

def num(s):
    s = re.sub(r"[^\d,.\-]", "", str(s or "").replace("\xa0", "").replace(" ", "")).replace(",", ".")
    try: return float(s)
    except ValueError: return 0.0

def to_ar(txt):
    t = (txt or "").lower(); v = num(t)
    if "ha" in t: return round(v * 100, 2)
    if "m2" in t or "m²" in t or "kv" in t: return round(v / 100, 2)
    return v

PURP = [("gyv", ("gyven", "vienbut", "individual")), ("zu", ("žemės ūkio", "zemes ukio", "ūkio")),
        ("miskas", ("miško", "miskas", "miškų")), ("kom", ("komerc", "pramon", "prekyb", "sandėl")),
        ("rek", ("rekreac", "sod", "poilsio"))]
def purpose(t):
    t = (t or "").lower()
    return next((k for k, ws in PURP if any(w in t for w in ws)), "kita")

def pick(el, sel):
    if not sel: return ""
    sel, _, attr = sel.partition("@")
    n = el.select_one(sel) if sel else el
    if not n: return ""
    return (n.get(attr) or "") if attr else n.get_text(" ", strip=True)

def geocode(q, cache):
    if not q: return None
    if q in cache: return cache[q]
    time.sleep(1.1)  # Nominatim: ≤1 užklausa/s
    try:
        r = S.get("https://nominatim.openstreetmap.org/search",
                  params={"q": q + ", Lietuva", "format": "json", "limit": 1, "countrycodes": "lt"}, timeout=30).json()
        cache[q] = [float(r[0]["lat"]), float(r[0]["lon"])] if r else None
    except Exception:
        cache[q] = None
    return cache[q]

def scrape(src):
    out = []
    if not src.get("enabled", True): return out
    if not allowed(src["url"]): print("robots.txt draudžia:", src["url"]); return out
    for page in range(1, src.get("pages", 1) + 1):
        url = src["url"] + (f"?page={page}" if page > 1 else "")
        try: r = S.get(url, timeout=40); r.raise_for_status()
        except Exception as e: print("klaida", url, e); break
        items = BeautifulSoup(r.text, "lxml").select(src["item"])
        if not items: break
        for it in items:
            f = {k: pick(it, v) for k, v in src["fields"].items()}
            out.append({"title": f.get("title") or "Sklypas", "type": src["type"], "seller": src["seller"],
                        "price": num(f.get("price")), "area": to_ar(f.get("area")), "address": f.get("address", ""),
                        "cad": f.get("cad", ""), "auction": f.get("auction", ""),
                        "url": urljoin(url, f["link"]) if f.get("link") else "",
                        "purpose": purpose(f.get("title", "") + " " + f.get("address", "")),
                        "muni": f.get("address", ""), "date": datetime.now(timezone.utc).date().isoformat(),
                        "notes": "Automatiškai surinkta: " + src["name"], "auto": True})
        time.sleep(2)
    return out

def manual():
    out = []
    for fn in glob.glob(str(ROOT / "manual/*.csv")):
        with open(fn, encoding="utf-8-sig") as fh:
            for r in csv.DictReader(fh):
                try: r["lat"], r["lng"] = float(r["lat"]), float(r["lng"])
                except (KeyError, ValueError, TypeError): continue
                for k in ("price", "area", "dist"): r[k] = num(r.get(k))
                for k in ("el", "water", "gas", "sewer"): r[k] = 1 if str(r.get(k, "0")).strip() in ("1", "true", "taip") else 0
                out.append(r)
    return out

def main():
    cache = json.loads(GEO.read_text()) if GEO.exists() else {}
    items = manual()
    for src in SOURCES:
        for p in scrape(src):
            g = geocode(p.get("address") or p.get("cad"), cache)
            if not g: continue
            p["lat"], p["lng"] = g
            items.append(p)
    seen, final = set(), []
    for p in items:
        k = p.get("cad") or p.get("url") or f'{p["title"]}{p["lat"]:.4f}{p["lng"]:.4f}'
        p["id"] = "A" + hashlib.md5(k.encode()).hexdigest()[:10]
        if p["id"] in seen or not p["price"] or not p["area"]: continue
        seen.add(p["id"]); final.append(p)
    GEO.write_text(json.dumps(cache, ensure_ascii=False))
    OUT.write_text(json.dumps({"updated": datetime.now(timezone.utc).isoformat(timespec="seconds"), "items": final},
                              ensure_ascii=False, indent=1))
    print(f"Įrašyta {len(final)} sklypų")

if __name__ == "__main__":
    main()
